export interface YachtResult {
    id_yacht: number;
    name: string;
    ft: string;
    image: string;
  }