export interface CrewResult {
    id_crew: number;
    position: string;
    name: string;
    lasname: string;
    age: string;
  }
