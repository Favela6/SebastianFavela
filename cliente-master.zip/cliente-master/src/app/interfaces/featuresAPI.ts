export interface FeaturesResult {
    id_feature: number;
    name: string;
    number: string;
    type: string;
    description: string;
  }